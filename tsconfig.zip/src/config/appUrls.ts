// src/config/appUrls.ts

export const appUrls = {
  theInternet: 'https://the-internet.herokuapp.com/',
  lambdaTest: 'https://www.lambdatest.com/selenium-playground/',
};
